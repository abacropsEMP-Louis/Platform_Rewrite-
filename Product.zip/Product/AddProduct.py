from flask import Flask, render_template, request, redirect, url_for, session
import re
import sys 

import db_Msql
from flask_mysqldb import MySQL
import MySQLdb.cursors



# Initialize the mysql platform 
app = Flask(__name__)

app.secret_key = 'key'


mYSQL = db_Msql.Initialize_Msql(app)



@app.route('/', methods=['GET', 'POST'])
def products():
    msg = False
    name = ""   

    #ARRAY OF CLASSIFICATION VALUES 
    classifications=['None','Semillas','Fertilizantes', "Control de plagas","Insumos de mantenimiento","Uso humano"]

    # This is the classification value of the types of product that the user can create
    clasification_value = request.form.get('Classification')
    
    
    #################### INPUT ( NAME & Brand ) ######################
    # THIS INPUT IS ONLY ENABLE WHEN THE USER ENTERS THE CLASSIFICATION clasification_value THAT HE WANT TO USE 
    Product_Name = request.form.get('Product_Name')
    
    
    Product_Brand = request.form.get('Product_Brand')


    #################### INPUT ( NAME & Brand ) ######################


    #################### INPUT ( EPA | PHI | REI ) ######################
    
    #EPA INTPUT
    EPA = request.form.get('Product.Epa')

    PHI = request.form.get('Product.Phi')

    REI = request.form.get('Product.Rei')

    #################### INPUT ( EPA | PHI | REI ) ######################


    #################### INPUT (TEMPETURE & MEASIREMENT) ###############

    Storage_temp = request.form.get('Product.TemperatureStorage')

    print("Storage Temp: " + str(Storage_temp))

    #TEMPETURE MEASUREMENT
    Mesurment_temp = request.form.get('Product.TemperatureTypeId')
    print("Mesurment Temp: "+ str(Mesurment_temp))

    #################### INPUT (TEMPETURE & MEASIREMENT) ###############


    #MYSQL THINGS
    cursor = ""

    # Option for the dropdown (Semillas)
    if (clasification_value == "1"):
        #MYSQL THINGS
        cursor = mYSQL.connection.cursor(MySQLdb.cursors.DictCursor)

        # JINJAX MESSAGE 
        msg = True
        
        #CLASSIFICATION NAME
        name = classifications[1]
        print("Mesurement temp: " + str(Mesurment_temp)) 
        db_Msql.Create_product_seeds(cursor=cursor, mYSQL=mYSQL, company_id='1', classification_id='1', Name=Product_Name, Brand=Product_Brand, EPA=EPA, temp_type=Mesurment_temp, temp=Storage_temp)

        return render_template('AddProductqty.html', msg=msg, name=name, value=clasification_value)


    # Option for the dropdown (Semillas)
    if (clasification_value == "2"):
        
        # JINJAX MESSAGE    
        msg = True

        #CLASSIFICATION NAME 
        name = classifications[2]
        if (Product_Name != None):
            print("Fertilizer")
            #Write fertilizer data to the mysql databases



        return render_template('AddProductqty.html', msg=msg, name=name, value=clasification_value)
    
    #Option for the dropdown (Control de plagas)
    if (clasification_value == "3"):
        
        #JINJAX MESSAGE 
        msg= True

        #CLASSIFICATION NAME
        name = classifications[3]

        return render_template('AddProductqty.html', msg=msg, name=name, value=clasification_value)

    if (clasification_value == "4"):
        # JINJAX MESSAGE
        msg = True

        #CLASSIFICATION NAME
        name = classifications[4]

        return render_template('AddProductqty.html', msg=msg, name=name, value=clasification_value)


    if (clasification_value == "5"):
        
        #JINJAX MESSAGE
        msg = True
        #CLASSIFICATION NAME
        name = classifications[5]
        
        return render_template('AddProductqty.html', msg=msg, name=name, value=clasification_value)
    
    return render_template('AddProductqty.html', msg=msg, name=name, value=clasification_value)






if __name__ == "__main__":
    app.run(host='127.0.0.1', port= 80, debug=True)

