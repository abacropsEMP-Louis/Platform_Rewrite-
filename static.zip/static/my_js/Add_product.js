
function displayElem(divId,  element){
    document.getElementById(divId).style.display = element.value != 'N' ? 'block' : 'none';
}