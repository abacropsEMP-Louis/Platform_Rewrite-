from flask import Flask, render_template, request, redirect, url_for, session
import re
import sys 
import db_Msql
from flask_mysqldb import MySQL
import MySQLdb.cursors
from datetime import datetime

# Initialize the mysql platform 
app = Flask(__name__)

app.secret_key = '$#$TR%$YGHGFDBG>'


mYSQL = db_Msql.Initialize_Msql(app)

#This is the Products function list
@app.route('/', methods=['GET', 'POST'])
def Products():
    session['Role'] = "Company";

    session['company_id'] = 1

    Classification_List=['semillas','Fertilizante','Control de Plagas', 'Insumos de mantenimiento', 'Uso humano']

    cursor = mYSQL.connection.cursor(MySQLdb.cursors.DictCursor)
    
    data = db_Msql.Get_product(cursor=cursor, mYSQL=mYSQL, company_id='1' )
    return render_template('index.html', User_Name = 'Louis Company' , Company_name='Louis Company', products=data, Classification_List=Classification_List)



############# Add New Product ##################
@app.route('/AddProduct', methods=['GET', 'POST'])
def AddProducts():
    if (session['Role'] == 'Company'):
        if (request.method == "POST"):
            print("Method Request")
            #EXTRACT DATA FROM TEMPLATE 
        
        ###############################################
        
            # requesting ( NAME & BRAND )
            Product_Name = request.form.get('Product_Name')
            Brand_Name =  request.form.get('Product_Brand')
            
            # requesting ( EPA | PHI | REI )
            EPA = request.form.get('Product.Epa')
            PHI = request.form.get('Product.Phi')
            REI = request.form.get('Product.Rei')

            # requesting (Tempeture | Mesurment )
            Storage_temp = request.form.get('Product.TemperatureStorage')
            Mesurment_temp = request.form.get('Product.TemperatureTypeId')

            # Product classification
            clasification_value = request.form.get('Classification')

            # Validate the DATA 

            #validate input to write it to databases;
            #if the len of PHI is equal to 0 the value goes null 
            if (len(PHI) == 0):
                PHI = None; 


        # if the len of REI is Equal to 0 the value goes null
            if (len(REI) == 0):
                REI = None;

            if (len(EPA) == 0 ):
                EPA =None


        #if Storage tempeture (int) == 0 value goes nul 
            if (len(Storage_temp) == 0 ):
                Storage_temp = None;
                Mesurment_temp = None;



    #Write data to databases
            cursor = mYSQL.connection.cursor(MySQLdb.cursors.DictCursor)


            db_Msql.Create_product(cursor=cursor, mYSQL=mYSQL, company_id=str(session['company_id']) ,  classification_id=clasification_value, Brand=Brand_Name, Name=Product_Name, PHI=PHI, REI=REI, EPA=EPA, temp_type=Mesurment_temp, temp=Storage_temp)


            return redirect(url_for('Products'))
    
        return render_template('AddProduct.html')

############# AddProduct ##################


#Create New Lots for the Selected product label
@app.route('/AddLot', methods=['GET', 'POST'])
def AddLot():

    if(request.method == "POST"):
        Product_Amount = request.form.get('Product_QTY_Amount')
        Measurement_id = request.form.get('Product_QTY_Measurement')
        Product_price = request.form.get('Product_QTY_Price')
        Lot_Number = request.form.get('Product_LOT_Number')
        print(Lot_Number)

    return render_template('AddLot.html', User_Name='Louis Company', Product_Name='test')



@app.route('/Test_table', methods=['GET', 'POST'])
def test_table():

    return render_template('test_table.html')
if __name__ == "__main__":
    app.run(host='127.0.0.1', port=80, debug=True)
